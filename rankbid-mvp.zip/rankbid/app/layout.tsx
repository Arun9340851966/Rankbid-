import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'RankBid — Compete for attention',
  description: 'A global pay-to-rank marketplace for businesses and creators.'
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
